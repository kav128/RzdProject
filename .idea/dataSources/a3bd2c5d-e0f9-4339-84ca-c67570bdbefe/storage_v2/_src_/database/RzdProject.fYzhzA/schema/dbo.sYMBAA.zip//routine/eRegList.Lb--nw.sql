CREATE FUNCTION eRegList (@train NVARCHAR(5), @date DATE)
  RETURNS TABLE
  AS RETURN (SELECT railcar, seat, stationFrom, stationTo,
                    dbo.fullName(firstName, middleName, lastName) AS passengerName,
                    passportID
             FROM TicketDetails
             WHERE train = '004A' AND tripDate = '2018-11-06')
go

