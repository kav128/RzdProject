CREATE VIEW NightTrains AS
SELECT train, station, departure
FROM schedule
WHERE arrival IS NULL AND departure BETWEEN '00:00:00' AND '06:00:00'
go

