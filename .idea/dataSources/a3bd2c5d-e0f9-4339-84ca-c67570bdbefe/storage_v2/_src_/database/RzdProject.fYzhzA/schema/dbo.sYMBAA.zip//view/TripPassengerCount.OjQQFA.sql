CREATE VIEW TripPassengerCount AS
SELECT train, tripDate, COUNT(*) AS passengerCount
FROM TicketDetails
GROUP BY train, tripDate
go

