CREATE PROCEDURE deleteOldData
  AS
  BEGIN
    DECLARE @@tripid INT
    DECLARE @@ticketId INT
    DECLARE @@date DATE
    DECLARE @@curDate DATE
    SET @@curDate = GETDATE()
    
    DECLARE tripCur CURSOR DYNAMIC FOR
      SELECT id, tripDate FROM trips
    OPEN tripCur
    FETCH NEXT FROM tripCur INTO @@tripid, @@date
    WHILE @@FETCH_STATUS = 0
    BEGIN 
      IF @@date < @@curDate
        BEGIN
          DECLARE ticketCur CURSOR SCROLL FOR
            SELECT id FROM tickets WHERE trip = @@tripid
          OPEN ticketCur
          FETCH NEXT FROM tripCur INTO @@ticketId
          WHILE @@FETCH_STATUS = 0
            BEGIN
              DELETE FROM tickets WHERE id = @@ticketId
              FETCH NEXT FROM tripCur INTO @@ticketId
            END
          CLOSE ticketCur
          DEALLOCATE ticketCur
          DELETE FROM trips WHERE id = @@tripid
        END
      FETCH NEXT FROM tripCur INTO @@tripid, @@date
    END
    CLOSE tripCur
    DEALLOCATE tripCur
  END
go

