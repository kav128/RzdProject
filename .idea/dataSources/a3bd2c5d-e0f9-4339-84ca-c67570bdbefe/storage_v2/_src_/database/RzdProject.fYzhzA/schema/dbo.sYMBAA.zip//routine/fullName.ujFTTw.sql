CREATE FUNCTION fullName (@fn NVARCHAR(30), @mn NVARCHAR (30), @ln NVARCHAR(30))
  RETURNS NVARCHAR(92)
  BEGIN
    DECLARE @full NVARCHAR(92)

    SET @full = @fn + ' '
    IF @mn IS NOT NULL
      SET @full = @full + @mn + ' '
    SET @full = @full + @ln
    RETURN @full
  END
go

