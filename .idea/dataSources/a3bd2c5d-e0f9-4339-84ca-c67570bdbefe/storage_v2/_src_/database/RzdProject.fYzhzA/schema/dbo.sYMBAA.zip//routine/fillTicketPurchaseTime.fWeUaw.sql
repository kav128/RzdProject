CREATE PROCEDURE fillTicketPurchaseTime
  AS
  BEGIN
    DECLARE @@id INT
    DECLARE @@pd DATETIME
    DECLARE cur CURSOR STATIC FOR
      SELECT id, purchaseTime FROM tickets WHERE purchaseTime IS NULL
    OPEN cur
    FETCH NEXT FROM cur INTO @@id, @@pd
    WHILE @@FETCH_STATUS = 0
    BEGIN
      UPDATE tickets
      SET purchaseTime = GETDATE()
      WHERE id = @@id
      FETCH NEXT FROM cur INTO @@id, @@pd
    END
    CLOSE cur
    DEALLOCATE cur
  END
go

