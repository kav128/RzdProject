CREATE FUNCTION fullNameFromId (@passengerID INT)
  RETURNS NVARCHAR(92)
  BEGIN
    DECLARE @fn NVARCHAR(30), @mn NVARCHAR(30), @ln NVARCHAR(30), @full NVARCHAR(92)
    SELECT @fn = firstName, @mn = middleName, @ln = lastName
    FROM passengers
    WHERE id = @passengerID

    RETURN dbo.fullName(@fn, @mn, @ln)
  END
go

