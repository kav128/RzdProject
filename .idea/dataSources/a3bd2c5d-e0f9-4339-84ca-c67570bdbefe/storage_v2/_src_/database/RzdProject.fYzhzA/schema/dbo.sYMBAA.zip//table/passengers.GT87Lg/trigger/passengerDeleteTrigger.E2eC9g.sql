CREATE TRIGGER passengerDeleteTrigger
  ON passengers
  INSTEAD OF DELETE
  AS
  BEGIN
    DECLARE @@ID INT
    SET @@ID = (SELECT id FROM deleted)
    DECLARE @@CNT INT
    SET @@CNT = (SELECT COUNT(*) FROM tickets WHERE passengerID = @@ID)
    IF @@CNT = 0
      DELETE FROM passengers WHERE id = @@ID
    ELSE
      ROLLBACK
  END
go

