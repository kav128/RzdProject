CREATE TRIGGER scheduleModifyTrigger
  ON schedule
  FOR UPDATE
  AS
  UPDATE schedule SET schedule.lastModified = GETDATE()
go

