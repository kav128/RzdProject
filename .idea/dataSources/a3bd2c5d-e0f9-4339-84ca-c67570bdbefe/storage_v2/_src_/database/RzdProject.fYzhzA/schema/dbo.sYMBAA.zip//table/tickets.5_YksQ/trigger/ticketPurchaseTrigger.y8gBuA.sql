CREATE TRIGGER ticketPurchaseTrigger
  ON tickets AFTER INSERT
  AS
  BEGIN
    DECLARE @@id INT
    SET @@id = (SELECT id FROM inserted)
    UPDATE tickets
    SET purchaseTime = getdate()
    WHERE id = @@id
  END
go

