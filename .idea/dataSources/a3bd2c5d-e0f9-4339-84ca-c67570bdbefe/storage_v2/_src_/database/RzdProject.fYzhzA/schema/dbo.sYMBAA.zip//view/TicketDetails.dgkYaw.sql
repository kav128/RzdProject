CREATE VIEW TicketDetails AS
SELECT t.train, tripDate, sequencePosition AS railcar, seat, s2.name AS stationFrom, s3.name AS stationTo, firstName, middleName, lastName, passportID
FROM tickets
INNER JOIN passengers p ON tickets.passengerID = p.id
INNER JOIN stations s2 ON tickets.stationFrom = s2.id
INNER JOIN stations s3 ON tickets.stationTo = s3.id
INNER JOIN trips t ON tickets.trip = t.id
INNER JOIN railcars r ON tickets.railcar = r.id
go

